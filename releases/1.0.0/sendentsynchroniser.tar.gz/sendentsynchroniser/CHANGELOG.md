# Changelog

## 1.0.0 - 2024-02-17

### First release
Synchronise your Office 365 calendar and contacts with Nextcloud Caldav and Carddav so you can view and edit everything from Nextcloud.
