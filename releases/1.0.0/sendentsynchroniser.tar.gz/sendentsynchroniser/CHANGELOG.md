# Changelog

## 1.0.0 - 2023-06-03

### Initial beta version

- Easy to configure synchronization-by-group using the drag-and-drop feature we borrowed from the original Sendent app for Nextcloud Group Settings feature.
