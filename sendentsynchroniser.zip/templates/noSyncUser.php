<div class="settingTemplateDetailInclude section" id="groupsManagement">
    <h2>
        <?php p($l->t('Sendent Sync Consent')); ?>
    </h2>

	<div class="license-settings-setting-box">
        <div class="settingkeyvalue">
<div class="labelFullWidth">
            <div style="margin-bottom:10px;" class="labelFullWidth">
			<p> 
				<?php p($l->t("Your IT department has not configured Sendent Synchroniser yet. Let them know if you want your Outlook content to be synced with Nextloud.")); ?>
			</p>
			</div>  
        </div>
		</div>
    </div>
</div>
