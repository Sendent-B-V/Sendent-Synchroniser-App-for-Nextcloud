<?php

namespace OCA\SendentSynchroniser\Service;

use Exception;

class StorageException extends Exception {
}
