<?php

namespace OCA\SendentSynchroniser\Service;

use Exception;

class ServiceException extends Exception {
}
