<?php

namespace OCA\SendentSynchroniser\Service;

class NotFoundException extends ServiceException {
}
